gdjs.NewSceneCode = {};
gdjs.NewSceneCode.GDNewObjectObjects1= [];
gdjs.NewSceneCode.GDNewObjectObjects2= [];
gdjs.NewSceneCode.GDNewObject2Objects1= [];
gdjs.NewSceneCode.GDNewObject2Objects2= [];
gdjs.NewSceneCode.GDNewObject3Objects1= [];
gdjs.NewSceneCode.GDNewObject3Objects2= [];
gdjs.NewSceneCode.GDNewObject4Objects1= [];
gdjs.NewSceneCode.GDNewObject4Objects2= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};


gdjs.NewSceneCode.eventsList0xac780 = function(runtimeScene, context) {

{


{
gdjs.NewSceneCode.GDNewObjectObjects1.createFrom(runtimeScene.getObjects("NewObject"));
gdjs.NewSceneCode.GDNewObject3Objects1.createFrom(runtimeScene.getObjects("NewObject3"));
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.NewSceneCode.GDNewObjectObjects1.length !== 0 ? gdjs.NewSceneCode.GDNewObjectObjects1[0] : null), true, "", 0);
}{}{for(var i = 0, len = gdjs.NewSceneCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNewObjectObjects1[i].returnVariable(gdjs.NewSceneCode.GDNewObjectObjects1[i].getVariables().getFromIndex(0).getChild("X")).setNumber((( gdjs.NewSceneCode.GDNewObject3Objects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDNewObject3Objects1[0].getX()));
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNewObjectObjects1[i].returnVariable(gdjs.NewSceneCode.GDNewObjectObjects1[i].getVariables().getFromIndex(0).getChild("Y")).setNumber((( gdjs.NewSceneCode.GDNewObject3Objects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDNewObject3Objects1[0].getY()));
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0xac780


gdjs.NewSceneCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.NewSceneCode.GDNewObjectObjects1.length = 0;
gdjs.NewSceneCode.GDNewObjectObjects2.length = 0;
gdjs.NewSceneCode.GDNewObject2Objects1.length = 0;
gdjs.NewSceneCode.GDNewObject2Objects2.length = 0;
gdjs.NewSceneCode.GDNewObject3Objects1.length = 0;
gdjs.NewSceneCode.GDNewObject3Objects2.length = 0;
gdjs.NewSceneCode.GDNewObject4Objects1.length = 0;
gdjs.NewSceneCode.GDNewObject4Objects2.length = 0;

gdjs.NewSceneCode.eventsList0xac780(runtimeScene, context);return;
}
gdjs['NewSceneCode']= gdjs.NewSceneCode;
